package tg.eplcoursandroid.recettecuisine

import android.view.View
import androidx.recyclerview.widget.RecyclerView
import tg.eplcoursandroid.recettecuisine.databinding.RecetteBinding
import tg.eplcoursandroid.recettecuisine.models.Recette

class RecetteViewHolder(val ui: RecetteBinding) : RecyclerView.ViewHolder(ui.root){
    companion object {

    }
    var recetteId: Int? = null
    lateinit var onItemClick : (Int) -> Unit

    var recette: Recette?
        get() = null
        set(recette) {
            if (recette == null) return
            this.recetteId = recette.id
            ui.image.setImageResource(recette.imageId ?: R.drawable.ic_launcher_foreground)
            ui.titre.text=recette.titre
            ui.tempsPreparation.text = recette.tempsPreparation.toString()
            ui.categorie.text=recette.categorie


        }

    init {
        ui.root.setOnClickListener(this::onClick)
    }

    private fun onClick(view: View?) {
        TODO("Not yet implemented")
    }
}