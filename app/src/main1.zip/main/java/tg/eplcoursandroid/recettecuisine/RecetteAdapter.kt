package tg.eplcoursandroid.recettecuisine

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import io.realm.RealmResults
import tg.eplcoursandroid.recettecuisine.databinding.RecetteBinding
import tg.eplcoursandroid.recettecuisine.models.Recette

class RecetteAdapter(private val recettes: RealmResults<Recette>) : RecyclerView.Adapter<RecetteViewHolder>() {
    lateinit var onItemClick: (Int?) -> Unit
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecetteViewHolder {
        val ui = RecetteBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RecetteViewHolder(ui)
    }

    override fun getItemCount(): Int {
        return recettes.size
    }

    override fun onBindViewHolder(holder: RecetteViewHolder, position: Int) {
        holder.recette = recettes[position]
        //holder.onItemClick = onItemClick

    }

}