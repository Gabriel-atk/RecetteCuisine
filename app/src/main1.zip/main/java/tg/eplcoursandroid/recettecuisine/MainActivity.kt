package tg.eplcoursandroid.recettecuisine

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.FragmentManager
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.bottomnavigation.BottomNavigationView
import io.realm.Realm
import tg.eplcoursandroid.recettecuisine.databinding.ActivityMainBinding
import tg.eplcoursandroid.recettecuisine.models.Recette

class MainActivity : AppCompatActivity() {
    private lateinit var ui: ActivityMainBinding
    private  lateinit var realm: Realm
    val bottomNavigation = findViewById<BottomNavigationView>(R.id.bottom_navigation)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ui = ActivityMainBinding.inflate(layoutInflater)
        setContentView(ui.root)
        bottomNavigation.setOnItemSelectedListener{ item ->
            when (item.itemId) {
                R.id.nav_recipes -> {
                    onMainActivity()
                    true
                }
                R.id.nav_favorites -> {
                    onFavoritesActivity()
                    true

                }
                else -> false
            }


        }

        Realm.init(this)
        realm = Realm.getDefaultInstance()

        val recettes = realm.where(Recette::class.java).findAllAsync()
        val adapter = RecetteAdapter(recettes)
        ui.recycler.adapter = adapter
        ui.recycler.setHasFixedSize(true)
        val layoutManager = LinearLayoutManager(this)
        ui.recycler.layoutManager = layoutManager
        val dividerItemDecoration = androidx.recyclerview.widget.DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
        ui.recycler.addItemDecoration(dividerItemDecoration)

    }

    private fun onFavoritesActivity() {
        TODO("Not yet implemented")
    }

    private fun onMainActivity() {
        TODO("Not yet implemented")
    }



    override fun onDestroy() {
        super.onDestroy()
        realm.close()
    }

    private fun onItemClicked(recetteId: Int?) {
        realm.executeTransactionAsync {
            val recette = it.where(Recette::class.java).equalTo("id", recetteId).findFirst()
            TODO("Que faire pour afficher la recette")
        }
    }
}