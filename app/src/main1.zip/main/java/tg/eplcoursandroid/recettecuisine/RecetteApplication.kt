package tg.eplcoursandroid.recettecuisine

import android.app.Application
import io.realm.Realm
import io.realm.RealmConfiguration
import tg.eplcoursandroid.recettecuisine.models.Recette

class RecetteApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Realm.init(this)
        val config = RealmConfiguration.Builder()
            .name("recettecuisine.realm")
            .deleteRealmIfMigrationNeeded()
            .compactOnLaunch()
            .build()
        Realm.setDefaultConfiguration(config)
        val realm = Realm.getDefaultInstance()
    }

    fun initRecettes(realm: Realm){
        if (realm.where(Recette::class.java).count() > 0) return
            realm.executeTransactionAsync {
                val res = resources
                val titres = res.getStringArray(R.array.titres)
                val descriptions = res.getStringArray(R.array.descriptions)
                val tempsPrepa = res.getIntArray(R.array.tempsPreparation)
                val categories = res.getStringArray(R.array.categories)
                val ingredients = res.getStringArray(R.array.ingredients)
                val etapes = res.getStringArray(R.array.etapes)
                for (i in 0..titres.size-1){
                    val recette = realm.createObject(Recette::class.java, i)
                    recette.titre = titres[i]
                    recette.description = descriptions[i]
                    recette.tempsPreparation = tempsPrepa[i]
                    //recette.categorie = categories[i]
                    recette.ingredients = ingredients[i]
                    recette.etapes = etapes[i]
                }

            }
        //TODO liberer les images

    }
}